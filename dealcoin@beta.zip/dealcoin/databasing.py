import dealcoin.wallets
import dealcoin.transactions
import sqlite3
import threading


DEALCOIN_DB_TEMPLATE = 'dealcoinBase.sql'
DEALCOIN_DB_FILE = 'dealcoin.db'


class dealDB(object):
	""" dealcoin database class """

	def __init__(self, dbFile = DEALCOIN_DB_FILE):
		
		self.dbFile = dbFile
		self.dblock = threading.Lock()

	def doQuery(self, query, args=False, result='all'):
		''' Perform a thread-safe query on the database '''

		self.dblock.acquire()

		self.conn = sqlite3.connect(self.dbFile)
		self.cursor = self.conn.cursor()

		if args:
			self.cursor.execute(query, args)
		else:
			self.cursor.execute(query)

		res = ''
		if result == 'all':
			res = dealcoin.db.cursor.fetchall()
		if result == 'one':
			res = dealcoin.db.cursor.fetchone()

		self.conn.commit()
		self.conn.close()

		self.dblock.release()

		return res


	def createDB(self):
		''' Create database from template and create wallet '''

		# maak db met genesis transaction en wallet
		sql = open(DEALCOIN_DB_TEMPLATE,'r').read() 
		tmpConn = sqlite3.connect(self.dbFile)
		tmpCursor = tmpConn.cursor()
		tmpCursor.executescript(sql)
		tmpConn.commit()
		tmpConn.close()

		dealcoin.wallets.createNewWallet()